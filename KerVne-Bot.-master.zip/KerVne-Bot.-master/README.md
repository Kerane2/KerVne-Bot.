<p align="center">  
  <a href="">
    <img alt="NARUTO" height="300" src="https://telegra.ph/file/0b76086099a9a8e4ce244.jpg">
    <h1 align="center">NARUTO-BUG 1.1</h1>
  </a>
</p>
<p align="center">
<a href="https://t.me/ednut_x"><img title="Author" src="https://img.shields.io/badge/NARUTO-BOT-black?style=for-the-badge&logo=telegram"></a>
<p/>
<p align="center">
<a href="https://github.com/Ednut001?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Ednut001?label=Followers&style=social"></a>
<a href="https://github.com/Ednut001/Naruto-v1-bug/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Ednut001/Naruto-v1-bug?&style=social"></a>
<a href="https://github.com/Ednut001/Naruto-v1-bug/network/members"><img title="Fork" src="https://img.shields.io/github/forks/Ednut001/Naruto-v1-bug?style=social"></a>
<a href="https://github.com/Ednut001/Naruto-v1-bug/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Ednut001/Naruto-v1-bug?label=Watching&style=social"></a>
</p>

####  
NARUTO-V1-BUG Whatsapp crasher Multi Device whatsapp bot.

***

####
``` what new ? ```
Added video menu 
Added Additional commands
Fixed all commands
Added pc bugs 
and many more....

#### SETUP

1. Fork the repo
    <br>
<a href='https://github.com/Ednut001/Naruto-v1-bug/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



2. Get Session ID (Plus session id updated)
   > if not generating code please use the second one or scan method
    
     <a href='https://ednut-tech-web.onrender.com' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>
     

#### DEPLOY TO Toystack

1. If You don't have an account in Toystack. Create an account.
    <br>
<p align="center"><a href="https://toystack.ai"> <img src="https://img.shields.io/badge/Toystack%20Account-blue?style=for-the-badge&logo=Toystack" width="220" height="38.45"/></a></p>

#### DEPLOY TO HEROKU(no ban)

1. If You don't have an account in Heroku. Create a account.
    <br>
<p align="center"><a href="https://signup.heroku.com"> <img src="https://img.shields.io/badge/heroku%20Account-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
## `BUILDPACKS FOR HEROKU`

```
heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

#### DEPLOY TO KOYEB

1. if you don't have a koyeb account. Create an account.
   <br>
   <p align="center"><a href="https://app.koyeb.com/auth/signup"> <img src="https://img.shields.io/badge/Koyeb account-blue?style=for-the-badge&logo=koyeb" width="220" height="38.45"/></a></p>
 
 ## For more deployment platform join channel for update

SUPPORT CHANNEL: <a href="https://whatsapp.com/channel/0029VaefL9g0gcfLITSc841W"><img alt="WhatsApp" src="https://img.shields.io/badge/Join CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

- Star ⭐ the repo if you like NARUTO-BUG.


## `Main Dev` 
<a href="https://github.com/Ednut001"><img src="https://i.imgur.com/QvvICDx.jpeg" width="250" height="250" alt="Ednut"/></a>
  
`NARUTO-V1-BUG - By Ednut001`

<h2 align="center">  Reminder
</h2>
   
## 
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.
- use this bot with wisdom if any report of misusing this im not responsible and you will bear for the consiquences 
